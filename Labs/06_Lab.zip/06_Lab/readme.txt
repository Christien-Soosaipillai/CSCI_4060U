to run the code for lab 6 use the following command:
gcc -pthread lab06.c -lm
./a.out 5 100 10
./a.out 5 2500 25
./a.out 50 2500 25
